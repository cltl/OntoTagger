java -Xmx812m -cp ../lib/KyotoKafSaxParser-1.0-jar-with-dependencies.jar eu.kyotoproject.util.DependenciesToTermAttribute "../example/bus-accident.ont.kaf" > "../example/bus-accident.ont.dep.kaf"
